from datetime import datetime
from django.http import HttpResponse
from django.shortcuts import redirect, render
from django.views.generic import ListView
from customer.forms import LogMessageForm
from customer.forms import QuestionaireForm
from customer.models import customer
from customer.models import Questionaire
from django.http import JsonResponse
from django.shortcuts import render
from django.core import serializers


class LogListView(ListView):
    #Prepare the log message objects as a list to ne passed to the template.
    model = customer
    template_name="comments.html"
    context_object_name="customer_list"
    queryset=customer.objects.order_by("name")
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        return context


def searchAjax(request,q):
    lis = customer.objects.filter(date__contains=q)
    out="<table><tr><th>name</th><th>comment</tr></tr>"
    for x in lis:
        out+="<tr><td>"+ x.name +"</td><td>" + x.comment +"</td></tr>"
    out+="</table>"
    return HttpResponse(out)

def FAQ(request):
    return render(request, "FAQ.html")

def Finished(request):
    return render(request, "Finished.html")

def Home(request):
    return render(request, "Home.html")


def Important(request):
    return render(request, "Important.html")


def Comments(request):
    return render(request, "Comments.html")
  


def log_message(request):
    form = LogMessageForm(request.POST or None)
    print(request.POST.get("customer"))
    
    if request.method == "POST":
        if form.is_valid():
            customer = form.save(commit=False)
            customer.save()
            return redirect("Home")
        else:
            return render(request, "log_message.html", {"form": form})
    else:
        return render(request, "log_message.html", {"form": form})

def log_questionaire(request):
    form = QuestionaireForm(request.POST or None)
    print(request.POST.get("Questionaire"))
    
    if request.method == "POST":
        if form.is_valid():
            Questionaire = form.save(commit=False)
            Questionaire.save()
            return redirect("Finished")
        else:
            return render(request, "Questionaire.html", {"form": form})
    else:
        return render(request, "Questionaire.html", {"form": form})