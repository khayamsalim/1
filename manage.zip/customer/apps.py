from django.apps import AppConfig
from django.contrib.staticfiles


class CustomerConfig(AppConfig):
    name = 'customer'
