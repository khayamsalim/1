from django.urls import path
from customer import views
from customer.models import customer
from customer.models import Questionaire


urlpatterns = [
    path("", views.Home, name="Home"),
    path("Questionaire/", views.log_questionaire, name="Questionaire"),
    path("searchAjax/<q>", views.searchAjax, name="searchAjax"),
    path("FAQ/", views.FAQ, name="FAQ"),
    path("Important/", views.Important, name="Important"),
    path("log/", views.log_message, name="log"),
    path("Comments/", views.Comments, name="Comments"),
    path("Finished/", views.Finished, name="Finished"),
]


